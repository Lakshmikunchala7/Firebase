package com.example.lucky.navigate;

import java.util.AbstractList;
import java.util.ArrayList;

/**
 * Created by LUCKY on 04-Jul-17.
 */

public class ModelProducts {
    private String productName;
    private String productDesc;
    private int productPrice;

    public ModelProducts(String productName,String productDesc,int productPrice){
        this.productName=productName;
        this.productDesc=productName;
        this.productPrice=productPrice;
    }
    public String getProductName(){
        return productName;
    }
    public String getProductDesc(){
        return productDesc;
    }
    public int getProductPrice(){
        return productPrice;
    }

}
