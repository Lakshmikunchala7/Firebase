package com.example.lucky.navigate;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ResourceBundle;
import java.util.jar.Attributes;


public class MainActivity extends AppCompatActivity {
   // public ListView listview

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final LinearLayout layout=(LinearLayout)findViewById(R.id.LinearMain);
        final Button btn=(Button)findViewById(R.id.second);
        final Controller ct = (Controller) getApplicationContext();


        ModelProducts products = null;

        for (int i=0;i<=7;i++){
            int Price = 15+ i;

            products = new ModelProducts("Product Item" +i,"productDesc" +i, Price);
            ct.setProducts(products);
        }
        int productsize = ct.getProductArraylistsize();
        LinearLayout.LayoutParams params=new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        for (int j=0; j<productsize; j++){
            String pName = ct.getProducts(j).getProductName();
            int Price = ct.getProducts(j).getProductPrice();

            LinearLayout la=new LinearLayout(this);
            la.setOrientation(LinearLayout.HORIZONTAL);

            TextView tv=new TextView(this);
            tv.setText(" "+pName+"");
            la.addView(tv);
            TextView tv1=new TextView(this);
            tv1.setText("$"+Price+"");
            la.addView(tv1);

            final Button btn1=new Button(this);
            btn1.setId(j+1);
            btn1.setText("Add to cart");

            btn1.setLayoutParams(params);
            final int index = j;
            btn1.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Log.i("TAG","index"+index);

                    ModelProducts productsObject = ct.getProducts(index);
                    if(!ct.getCart().CheckProductInCart(productsObject))
                    {
                        btn1.setText("Added");
                        ct.getCart().setProducts(productsObject);
                        Toast.makeText(getApplicationContext(), "New CartSize:" + ct.getCart().getCartSize(), Toast.LENGTH_LONG).show();
                    }
                    else{
                        Toast.makeText(getApplicationContext(),"Products"+(index+1)+"Already adde",Toast.LENGTH_LONG).show();
                    }
                }
            });

            la.addView(btn1);
            layout.addView(la);

            btn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent in=new Intent(getBaseContext(),Screen1.class);
                    startActivity(in);
                }
            });
        }

    }

}
