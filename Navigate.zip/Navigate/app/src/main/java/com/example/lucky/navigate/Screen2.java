package com.example.lucky.navigate;

import android.app.Activity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

/**
 * Created by LUCKY on 05-Jul-17.
 */

public class Screen2 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.screen2);

        TextView showCartContent=(TextView)findViewById(R.id.showcart);

        final Controller ct=(Controller)getApplicationContext();
        final int CartSize= ct.getCart().getCartSize();
        String show = "";

        for(int i=0;i<CartSize;i++){
            String pName=ct.getCart().getProducts(i).getProductName();
            int pPrice=ct.getCart().getProducts(i).getProductPrice();
            String pDisc=ct.getCart().getProducts(i).getProductDesc();

            show += "Product Name:"+pName+"\n "+"Price:"+pPrice+" \n"+"Discription:"+pDisc+""+"........."+"\n";
        }
        showCartContent.setText(show);
    }

}
