package com.example.lucky.navigate;

import android.app.Application;

import java.util.AbstractList;
import java.util.ArrayList;

/**
 * Created by LUCKY on 04-Jul-17.
 */

public class Controller extends Application{

    private AbstractList<ModelProducts> myproducts=new ArrayList<ModelProducts>();

    private ModelCart myCart=new ModelCart();

    public ModelProducts getProducts(int pPosition) {
        return myproducts.get(pPosition);
    }

    public void setProducts(ModelProducts products) {
        myproducts.add(products);
    }
    public ModelCart getCart(){
        return myCart;
    }


    public int getProductArraylistsize() {
        return myproducts.size();
    }



}
